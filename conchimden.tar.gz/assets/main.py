# -*- coding: utf-8 -*-
import asyncio
import pygame
pygame.init()

p=0.5   
bird_y=-14
score=0
game_play=True
h_score=0
game_font=pygame.font.Font("assets/04B_19.TTF",40)
def score_view():
    if game_play:
        score_f=game_font.render(f"Score: {str(int(score))}",True,(255,255,255))
        score_hcn=score_f.get_rect(center=(200,40))
        screen.blit(score_f,score_hcn)
    else :
        score_f = game_font.render(f"Score:{str(int(score))}", True, (255, 255, 255))
        score_hcn = score_f.get_rect(center=(200, 40))
        screen.blit(score_f, score_hcn)
        h_score_f = game_font.render(f"High Score:{str(int(h_score))}", True, (255, 255, 255))
        h_score_hcn = h_score_f.get_rect(center=(200, 100))
        screen.blit(h_score_f, h_score_hcn)
pygame.display.set_caption("Con chim đen")

icon = pygame.image.load("assets/yellowbird-downflap.png")
bg = pygame.image.load("assets/background-night.png")
fl = pygame.image.load("assets/floor.png")
bg=pygame.transform.scale2x(bg)
pygame.display.set_icon(icon)
fl_x=0

screen=pygame.display.set_mode((400,670))

bird1 = pygame.image.load("assets/yellowbird-midflap.png")
bird1=pygame.transform.scale2x(bird1)
bird_hcn=bird1.get_rect(center=(100,350))

screenover = pygame.image.load("assets/message.png")
screenover=pygame.transform.scale2x(screenover)
screenover_hcn=bird1.get_rect(center=(100,250))

def check_vc():
    if bird_hcn.bottom >= 570 or bird_hcn.top <=-75:
       return  False
    else: return True

async def main():
    global bird_y, score, game_play, h_score, fl_x, bird_hcn
   
    running=True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running=False
            # Bất kỳ phím nào
            if event.type == pygame.KEYDOWN:
                if game_play:
                    bird_y=-10
                else:
                    game_play=True
                    bird_y=0
                    bird_hcn.center=(60,100)
                    score=0

            # Click chuột
            if event.type == pygame.MOUSEBUTTONDOWN:
                if game_play:
                    bird_y=-10
                else:
                    game_play=True
                    bird_y=0
                    bird_hcn.center=(60,100)
                    score=0
        screen.blit(bg,(0,0))
        fl_x -= 1
        screen.blit(fl,(fl_x,550))
        screen.blit(fl, (fl_x+335, 550))
        if fl_x==-335:
            fl_x=0
        if game_play:
    
            screen.blit(bird1,(bird_hcn))
            bird_y+=p
            bird_hcn.centery+=bird_y
            score+=0.01
            if score>h_score:h_score=score
            score_view()
            game_play=check_vc()
        else :
            screen.blit(screenover,(screenover_hcn))
            score_view()
        pygame.display.update()
        await asyncio.sleep(0)  # bắt buộc cho pygbag

asyncio.run(main())
